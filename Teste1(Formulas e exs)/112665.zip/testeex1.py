import numpy as np
import matplotlib.pyplot as plt
import math
import sympy as sy


atividade=np.array([10.03,7.06,4.88,3.38,2.26,1.66,1.14,0.79,0.58])
tempo=np.array([0,48,96,144,192,240,288,336,384])

#--------------Regresão linear-----------------
def regreslinear(x,y): 

    somx=np.sum(x);
    somy=np.sum(y);
    somxy=np.sum(x*y);
    somx2=np.sum(x**2);
    somy2=np.sum(y**2);
    N=len(x);
    m=((N*somxy)-(somx*somy))/((N*somx2)-(somx)**2)

    b=((somx2*somy)-(somx*somxy))/((N*somx2)-(somx)**2)

    r2=(((N*somxy)-(somx*somy))**2)/(((N*somx2)-((somx)**2))*((N*somy2)-((somy)**2)))

    delM=np.abs(m)*(np.sqrt(((1/r2)-1)/(N-2)))
    delB=delM*(np.sqrt(somx2/N))

    
    return m,b,r2,delM,delB;

m,b,r2,delM,delB=regreslinear(tempo,atividade)
plt.scatter(tempo, atividade, marker="x",color="red")
retaajustada=m*tempo+b
plt.plot(tempo,retaajustada)
plt.xlabel("h/horas")
plt.ylabel("mBq/Beqquerel")
plt.xlim(0,400)
plt.ylim(0,11)

plt.title('Atividade em função do tempo ')
plt.grid(True)
plt.show()
print("O declive tem o valor de {:.4f}\n, a ordenada é {:.4f}\n, o coeficiente é {:.4f}\n, o erro associado ao declive é {:.4}\ne o erro associada á ordenada é {:.4f}\n".format(m,b,r2,delM,delB))


logy = np.log(atividade)

plt.scatter(tempo, logy, marker="x", label="Data points")
m,b,r2,delM,delB=regreslinear(tempo,logy)
reta=m*tempo+b
plt.plot(tempo,reta)
plt.xlabel("Tempo (horas)")
plt.ylabel("log(Atividade)")
plt.title('Log(Atividade) em função do tempo ')
print("O declive tem o valor de {:.4f}\n, a ordenada é {:.4f}\n, o coeficiente é {:.4f}\n, o erro associado ao declive é {:.4}\ne o erro associada á ordenada é {:.4f}\n".format(m,b,r2,delM,delB))
plt.show()


t1_2=-(np.log(2))/m
print(t1_2)


#------------------

#ex2

g=9.8
angulo = 30   #alterar(graus)
ang = np.deg2rad(angulo) #converter para radianos
vinicial = 15    #alterar
vterminal= 20  #alterar
D= g/vterminal**2

#valor da aceleração inciais em cada eixo
ay=-g
ax=0

#valor da velocidades inciais em cada eixo
vx0=vinicial*np.cos(ang)
vy0=vinicial*np.sin(ang)

#valor da posiçoes inciais em cada eixo
x0=0 #alterar (posiçao no solo)
y0=3 #alterar (altura)

tf = 5  #alterar
ti = 0   #alterar

step= 0.001
n = int((tf - ti) / step)
t=np.linspace(ti,n*step,n)

#vetores zeros....
x_=np.zeros(n)
y_=np.zeros(n)
vx_=np.zeros(n)
vy_=np.zeros(n)
ax_=np.zeros(n-1)
ay_=np.zeros(n-1)

#definir posições iniciais...
x_[0]=x0
y_[0]=y0
vx_[0]=vx0
vy_[0]=vy0

D= g/vterminal**2
for i in range(n-1):
    ax_[i]=ax-D*np.sqrt(vx_[i]**2+vy_[i]**2)*vx_[i]
    ay_[i]=ay-D*np.sqrt(vx_[i]**2+vy_[i]**2)*vy_[i]
    vx_[i+1]=vx_[i]+ax_[i]*step #sem resistencia ao ar vx_[i+1]=vx_[i]+ax*step
    vy_[i+1]=vy_[i]+ay_[i]*step #sem resistencia ao ar vy_[i+1]=vy_[i]+ay*step
    x_[i+1] =x_[i]+vx_[i]*step
    y_[i+1] =y_[i]+vy_[i]*step


plt.title('pena de badminton')
plt.plot(x_,y_, label='com resistencia')
plt.xlabel('x(m)') 
plt.ylabel('y(m)')
plt.legend()
plt.grid(True)
plt.show()

#b)----

t_0=0
for x in range(n):
    if y_[x]>=5:
        t_0=t[x]
        break

print('tempo de quando o volante comeca a cair: {:.2f}s e a distancia é: {:.2f}m. '.format(t_0,x_[int(t_0/step)]))   


